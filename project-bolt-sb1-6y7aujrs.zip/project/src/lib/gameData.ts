export interface CropData {
  id: string;
  name: string;
  seedCost: number;
  sellPrice: number;
  growTime: number;
  emoji: string;
}

export const CROPS: Record<string, CropData> = {
  wheat: {
    id: 'wheat',
    name: 'Grurë',
    seedCost: 10,
    sellPrice: 25,
    growTime: 60,
    emoji: '🌾'
  },
  corn: {
    id: 'corn',
    name: 'Misër',
    seedCost: 20,
    sellPrice: 50,
    growTime: 120,
    emoji: '🌽'
  },
  tomato: {
    id: 'tomato',
    name: 'Domate',
    seedCost: 15,
    sellPrice: 40,
    growTime: 90,
    emoji: '🍅'
  },
  carrot: {
    id: 'carrot',
    name: 'Karotë',
    seedCost: 12,
    sellPrice: 30,
    growTime: 75,
    emoji: '🥕'
  },
  pumpkin: {
    id: 'pumpkin',
    name: 'Kungull',
    seedCost: 30,
    sellPrice: 75,
    growTime: 180,
    emoji: '🎃'
  },
  strawberry: {
    id: 'strawberry',
    name: 'Luleshtrydhe',
    seedCost: 25,
    sellPrice: 60,
    growTime: 150,
    emoji: '🍓'
  }
};

export const GRID_SIZE = 6;
