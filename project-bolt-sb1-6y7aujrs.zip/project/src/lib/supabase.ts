import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Profile {
  id: string;
  username: string;
  coins: number;
  experience: number;
  level: number;
  created_at: string;
  updated_at: string;
}

export interface Plot {
  id: string;
  user_id: string;
  position_x: number;
  position_y: number;
  crop_type: string | null;
  planted_at: string | null;
  harvest_ready_at: string | null;
  is_unlocked: boolean;
  created_at: string;
}

export interface InventoryItem {
  id: string;
  user_id: string;
  item_type: string;
  quantity: number;
  created_at: string;
  updated_at: string;
}
