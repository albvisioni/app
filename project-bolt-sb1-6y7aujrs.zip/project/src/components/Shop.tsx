import { useState } from 'react';
import { CROPS } from '../lib/gameData';
import { ShoppingCart, X } from 'lucide-react';

interface ShopProps {
  coins: number;
  onBuySeeds: (cropType: string, amount: number) => void;
}

export function Shop({ coins, onBuySeeds }: ShopProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCrop, setSelectedCrop] = useState<string | null>(null);
  const [amount, setAmount] = useState(1);

  const handleBuy = () => {
    if (selectedCrop) {
      onBuySeeds(selectedCrop, amount);
      setSelectedCrop(null);
      setAmount(1);
    }
  };

  const selectedCropData = selectedCrop ? CROPS[selectedCrop] : null;
  const totalCost = selectedCropData ? selectedCropData.seedCost * amount : 0;
  const canAfford = totalCost <= coins;

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-full shadow-lg transition-all hover:scale-110"
      >
        <ShoppingCart className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-2xl w-full max-h-[85vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800">Dyqani i Farave</h2>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="bg-amber-50 border-2 border-amber-300 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-between">
                <span className="text-lg font-semibold text-gray-700">Monedhat e tua:</span>
                <span className="text-2xl font-bold text-amber-600">{coins} 💰</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.values(CROPS).map(crop => (
                <div
                  key={crop.id}
                  className="border-2 border-gray-200 rounded-xl p-4 hover:border-blue-500 transition-all"
                >
                  <div className="flex items-start gap-3">
                    <div className="text-5xl">{crop.emoji}</div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-gray-800">{crop.name}</h3>
                      <div className="text-sm text-gray-600 space-y-1 mt-2">
                        <div>Çmimi: <span className="font-semibold text-amber-600">{crop.seedCost}💰</span></div>
                        <div>Shitet për: <span className="font-semibold text-green-600">{crop.sellPrice}💰</span></div>
                        <div>Koha: <span className="font-semibold">{crop.growTime}s</span></div>
                      </div>
                      <button
                        onClick={() => {
                          setSelectedCrop(crop.id);
                          setAmount(1);
                        }}
                        className="mt-3 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors"
                      >
                        Bli Fara
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {selectedCrop && selectedCropData && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <div className="text-center mb-4">
              <div className="text-6xl mb-3">{selectedCropData.emoji}</div>
              <h3 className="text-2xl font-bold text-gray-800">{selectedCropData.name}</h3>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
                <span className="text-gray-700 font-semibold">Sasia:</span>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setAmount(Math.max(1, amount - 1))}
                    className="w-10 h-10 bg-gray-200 hover:bg-gray-300 rounded-lg font-bold transition-colors"
                  >
                    -
                  </button>
                  <span className="text-xl font-bold w-12 text-center">{amount}</span>
                  <button
                    onClick={() => setAmount(amount + 1)}
                    className="w-10 h-10 bg-gray-200 hover:bg-gray-300 rounded-lg font-bold transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-3">
                <div className="flex justify-between text-lg">
                  <span className="font-semibold text-gray-700">Totali:</span>
                  <span className={`font-bold ${canAfford ? 'text-amber-600' : 'text-red-600'}`}>
                    {totalCost} 💰
                  </span>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setSelectedCrop(null);
                    setAmount(1);
                  }}
                  className="flex-1 py-3 bg-gray-200 hover:bg-gray-300 rounded-xl font-semibold transition-colors"
                >
                  Anulo
                </button>
                <button
                  onClick={handleBuy}
                  disabled={!canAfford}
                  className={`flex-1 py-3 rounded-xl font-semibold transition-colors ${
                    canAfford
                      ? 'bg-green-600 hover:bg-green-700 text-white'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  Bli
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
