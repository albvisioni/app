import { useState } from 'react';
import { InventoryItem } from '../lib/supabase';
import { CROPS } from '../lib/gameData';
import { Package } from 'lucide-react';

interface InventoryProps {
  inventory: InventoryItem[];
}

export function Inventory({ inventory }: InventoryProps) {
  const [isOpen, setIsOpen] = useState(false);

  const getItemDisplay = (itemType: string) => {
    if (itemType.endsWith('_seed')) {
      const cropType = itemType.replace('_seed', '');
      const crop = CROPS[cropType];
      return {
        name: `Fara ${crop?.name || cropType}`,
        emoji: crop?.emoji || '🌱',
        isSeed: true
      };
    }

    const crop = CROPS[itemType];
    return {
      name: crop?.name || itemType,
      emoji: crop?.emoji || '🌾',
      isSeed: false
    };
  };

  const seeds = inventory.filter(item => item.item_type.endsWith('_seed'));
  const harvested = inventory.filter(item => !item.item_type.endsWith('_seed'));

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 left-6 bg-purple-600 hover:bg-purple-700 text-white p-4 rounded-full shadow-lg transition-all hover:scale-110"
      >
        <Package className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-2xl w-full max-h-[85vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800">Inventari</h2>
              <button
                onClick={() => setIsOpen(false)}
                className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg font-semibold transition-colors"
              >
                Mbyll
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold text-gray-700 mb-3 flex items-center gap-2">
                  <span>🌱</span>
                  <span>Farat</span>
                </h3>
                {seeds.length === 0 ? (
                  <div className="text-gray-500 text-center py-8 bg-gray-50 rounded-xl">
                    Nuk ke fara. Shko në dyqan për të blerë!
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {seeds.map(item => {
                      const display = getItemDisplay(item.item_type);
                      return (
                        <div
                          key={item.id}
                          className="bg-green-50 border-2 border-green-200 rounded-xl p-4 text-center"
                        >
                          <div className="text-4xl mb-2">{display.emoji}</div>
                          <div className="font-semibold text-gray-800 text-sm mb-1">
                            {display.name}
                          </div>
                          <div className="text-2xl font-bold text-green-600">
                            {item.quantity}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-700 mb-3 flex items-center gap-2">
                  <span>🌾</span>
                  <span>Të Korrurat</span>
                </h3>
                {harvested.length === 0 ? (
                  <div className="text-gray-500 text-center py-8 bg-gray-50 rounded-xl">
                    Nuk ke asgjë të korrur ende. Mbill dhe korr kulturat!
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {harvested.map(item => {
                      const display = getItemDisplay(item.item_type);
                      return (
                        <div
                          key={item.id}
                          className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4 text-center"
                        >
                          <div className="text-4xl mb-2">{display.emoji}</div>
                          <div className="font-semibold text-gray-800 text-sm mb-1">
                            {display.name}
                          </div>
                          <div className="text-2xl font-bold text-amber-600">
                            {item.quantity}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
