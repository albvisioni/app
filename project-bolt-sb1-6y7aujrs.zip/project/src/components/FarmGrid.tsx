import { useState } from 'react';
import { Plot } from '../lib/supabase';
import { CROPS, GRID_SIZE } from '../lib/gameData';
import { Sprout } from 'lucide-react';

interface FarmGridProps {
  plots: Plot[];
  onPlantCrop: (plotId: string, cropType: string) => void;
  onHarvestCrop: (plotId: string) => void;
}

export function FarmGrid({ plots, onPlantCrop, onHarvestCrop }: FarmGridProps) {
  const [selectedPlot, setSelectedPlot] = useState<string | null>(null);
  const [showCropSelector, setShowCropSelector] = useState(false);

  const getPlotByPosition = (x: number, y: number) => {
    return plots.find(p => p.position_x === x && p.position_y === y);
  };

  const getGrowthPercentage = (plot: Plot) => {
    if (!plot.planted_at || !plot.harvest_ready_at) return 0;

    const now = new Date().getTime();
    const plantedTime = new Date(plot.planted_at).getTime();
    const harvestTime = new Date(plot.harvest_ready_at).getTime();

    const totalTime = harvestTime - plantedTime;
    const elapsed = now - plantedTime;

    return Math.min(100, Math.max(0, (elapsed / totalTime) * 100));
  };

  const isReadyToHarvest = (plot: Plot) => {
    if (!plot.harvest_ready_at) return false;
    return new Date() >= new Date(plot.harvest_ready_at);
  };

  const handlePlotClick = (plot: Plot) => {
    if (!plot.crop_type) {
      setSelectedPlot(plot.id);
      setShowCropSelector(true);
    } else if (isReadyToHarvest(plot)) {
      onHarvestCrop(plot.id);
    }
  };

  const handleCropSelect = (cropType: string) => {
    if (selectedPlot) {
      onPlantCrop(selectedPlot, cropType);
      setShowCropSelector(false);
      setSelectedPlot(null);
    }
  };

  return (
    <div className="relative">
      <div
        className="grid gap-2"
        style={{
          gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
        }}
      >
        {Array.from({ length: GRID_SIZE }).map((_, y) =>
          Array.from({ length: GRID_SIZE }).map((_, x) => {
            const plot = getPlotByPosition(x, y);
            if (!plot) return null;

            const growthPercent = getGrowthPercentage(plot);
            const ready = isReadyToHarvest(plot);
            const crop = plot.crop_type ? CROPS[plot.crop_type] : null;

            return (
              <button
                key={`${x}-${y}`}
                onClick={() => handlePlotClick(plot)}
                className={`
                  aspect-square rounded-lg border-2 transition-all duration-200
                  ${plot.crop_type
                    ? ready
                      ? 'bg-green-100 border-green-500 hover:bg-green-200 hover:scale-105 animate-pulse'
                      : 'bg-amber-50 border-amber-300'
                    : 'bg-amber-900 border-amber-700 hover:bg-amber-800 hover:scale-105'
                  }
                  flex items-center justify-center relative overflow-hidden
                `}
              >
                {plot.crop_type && crop ? (
                  <>
                    <div className="text-3xl md:text-4xl z-10">
                      {crop.emoji}
                    </div>
                    {!ready && (
                      <div
                        className="absolute bottom-0 left-0 right-0 bg-green-500 opacity-30 transition-all duration-1000"
                        style={{ height: `${growthPercent}%` }}
                      />
                    )}
                    {ready && (
                      <div className="absolute inset-0 bg-green-400 opacity-20 animate-pulse" />
                    )}
                  </>
                ) : (
                  <Sprout className="w-6 h-6 md:w-8 md:h-8 text-amber-600 opacity-40" />
                )}
              </button>
            );
          })
        )}
      </div>

      {showCropSelector && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full max-h-[80vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4 text-gray-800">Zgjidh Kulturën</h2>
            <div className="grid grid-cols-2 gap-3">
              {Object.values(CROPS).map(crop => (
                <button
                  key={crop.id}
                  onClick={() => handleCropSelect(crop.id)}
                  className="p-4 border-2 border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all flex flex-col items-center gap-2"
                >
                  <div className="text-4xl">{crop.emoji}</div>
                  <div className="text-sm font-semibold text-gray-700">{crop.name}</div>
                  <div className="text-xs text-gray-500">{crop.growTime}s</div>
                </button>
              ))}
            </div>
            <button
              onClick={() => {
                setShowCropSelector(false);
                setSelectedPlot(null);
              }}
              className="w-full mt-4 py-3 bg-gray-200 hover:bg-gray-300 rounded-xl font-semibold transition-colors"
            >
              Anulo
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
