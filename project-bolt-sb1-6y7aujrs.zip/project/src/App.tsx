import { useGame } from './hooks/useGame';
import { FarmGrid } from './components/FarmGrid';
import { Shop } from './components/Shop';
import { Inventory } from './components/Inventory';
import { Loader2, RefreshCw } from 'lucide-react';

function App() {
  const {
    profile,
    plots,
    inventory,
    loading,
    plantCrop,
    harvestCrop,
    buySeeds,
    refreshData
  } = useGame();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-400 via-blue-500 to-purple-600 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-16 h-16 text-white animate-spin mx-auto mb-4" />
          <p className="text-white text-xl font-semibold">Duke ngarkuar Farma Ime...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-400 via-blue-500 to-purple-600 flex items-center justify-center">
        <div className="text-white text-xl">Duke inicializuar lojën...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-amber-50">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <div className="bg-white rounded-2xl shadow-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                Farma Ime
              </h1>
              <p className="text-gray-600 mt-1">{profile.username}</p>
            </div>
            <button
              onClick={refreshData}
              className="p-3 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
              title="Rifresko"
            >
              <RefreshCw className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl p-4 text-white shadow-lg">
              <div className="text-sm opacity-90 mb-1">Monedha</div>
              <div className="text-3xl font-bold flex items-center gap-2">
                {profile.coins} 💰
              </div>
            </div>
            <div className="bg-gradient-to-br from-purple-400 to-purple-600 rounded-xl p-4 text-white shadow-lg">
              <div className="text-sm opacity-90 mb-1">Niveli</div>
              <div className="text-3xl font-bold">{profile.level}</div>
            </div>
            <div className="bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl p-4 text-white shadow-lg">
              <div className="text-sm opacity-90 mb-1">XP</div>
              <div className="text-3xl font-bold">{profile.experience}</div>
            </div>
          </div>

          <FarmGrid
            plots={plots}
            onPlantCrop={plantCrop}
            onHarvestCrop={harvestCrop}
          />
        </div>

        <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-6 text-white shadow-2xl">
          <h2 className="text-2xl font-bold mb-3">Si të Luash</h2>
          <ul className="space-y-2 text-sm">
            <li className="flex items-start gap-2">
              <span className="text-xl">🌱</span>
              <span>Kliko në një parcele boshe për të mbjellë kultura</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-xl">⏰</span>
              <span>Prit që kulturat të rriten (shikim rritjen në parcele)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-xl">✨</span>
              <span>Kliko kulturat që pulsojnë për t'i korrur</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-xl">🛒</span>
              <span>Bli fara nga dyqani me monedhat që fiton</span>
            </li>
          </ul>
        </div>
      </div>

      <Shop coins={profile.coins} onBuySeeds={buySeeds} />
      <Inventory inventory={inventory} />
    </div>
  );
}

export default App;
