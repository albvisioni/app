import { useState, useEffect } from 'react';
import { supabase, Profile, Plot, InventoryItem } from '../lib/supabase';
import { GRID_SIZE, CROPS } from '../lib/gameData';

export function useGame() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [plots, setPlots] = useState<Plot[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    checkUser();
  }, []);

  useEffect(() => {
    if (userId) {
      loadGameData();
      const interval = setInterval(checkHarvestReady, 5000);
      return () => clearInterval(interval);
    }
  }, [userId]);

  async function checkUser() {
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      await signInAnonymously();
    } else {
      setUserId(user.id);
    }
  }

  async function signInAnonymously() {
    const username = `Fermier_${Math.floor(Math.random() * 10000)}`;
    const email = `${username.toLowerCase()}@farmaime.local`;
    const password = Math.random().toString(36).slice(-12);

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) {
      console.error('Error signing up:', error);
      return;
    }

    if (data.user) {
      setUserId(data.user.id);
      await initializeUserData(data.user.id, username);
    }
  }

  async function initializeUserData(uid: string, username: string) {
    await supabase.from('profiles').insert({
      id: uid,
      username,
      coins: 100,
      experience: 0,
      level: 1
    });

    const initialPlots = [];
    for (let y = 0; y < GRID_SIZE; y++) {
      for (let x = 0; x < GRID_SIZE; x++) {
        initialPlots.push({
          user_id: uid,
          position_x: x,
          position_y: y,
          is_unlocked: true
        });
      }
    }

    await supabase.from('plots').insert(initialPlots);

    for (const cropKey of Object.keys(CROPS)) {
      await supabase.from('inventory').insert({
        user_id: uid,
        item_type: `${cropKey}_seed`,
        quantity: 5
      });
    }

    loadGameData();
  }

  async function loadGameData() {
    setLoading(true);

    const { data: profileData } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    const { data: plotsData } = await supabase
      .from('plots')
      .select('*')
      .eq('user_id', userId)
      .order('position_y')
      .order('position_x');

    const { data: inventoryData } = await supabase
      .from('inventory')
      .select('*')
      .eq('user_id', userId);

    if (profileData) setProfile(profileData);
    if (plotsData) setPlots(plotsData);
    if (inventoryData) setInventory(inventoryData);

    setLoading(false);
  }

  async function checkHarvestReady() {
    if (!userId) return;

    const { data: plotsData } = await supabase
      .from('plots')
      .select('*')
      .eq('user_id', userId);

    if (plotsData) {
      setPlots(plotsData);
    }
  }

  async function plantCrop(plotId: string, cropType: string) {
    if (!profile || !userId) return;

    const crop = CROPS[cropType];
    const seedType = `${cropType}_seed`;
    const inventoryItem = inventory.find(item => item.item_type === seedType);

    if (!inventoryItem || inventoryItem.quantity < 1) {
      alert('Nuk ke fara të mjaftueshme!');
      return;
    }

    const plantedAt = new Date();
    const harvestReadyAt = new Date(plantedAt.getTime() + crop.growTime * 1000);

    await supabase
      .from('plots')
      .update({
        crop_type: cropType,
        planted_at: plantedAt.toISOString(),
        harvest_ready_at: harvestReadyAt.toISOString()
      })
      .eq('id', plotId);

    await supabase
      .from('inventory')
      .update({ quantity: inventoryItem.quantity - 1 })
      .eq('id', inventoryItem.id);

    loadGameData();
  }

  async function harvestCrop(plotId: string) {
    if (!profile || !userId) return;

    const plot = plots.find(p => p.id === plotId);
    if (!plot || !plot.crop_type || !plot.harvest_ready_at) return;

    const now = new Date();
    const harvestTime = new Date(plot.harvest_ready_at);

    if (now < harvestTime) {
      alert('Kultura nuk është gati ende!');
      return;
    }

    const crop = CROPS[plot.crop_type];
    const harvestedType = plot.crop_type;

    await supabase
      .from('plots')
      .update({
        crop_type: null,
        planted_at: null,
        harvest_ready_at: null
      })
      .eq('id', plotId);

    const newCoins = profile.coins + crop.sellPrice;
    await supabase
      .from('profiles')
      .update({ coins: newCoins })
      .eq('id', userId);

    const inventoryItem = inventory.find(item => item.item_type === harvestedType);
    if (inventoryItem) {
      await supabase
        .from('inventory')
        .update({ quantity: inventoryItem.quantity + 1 })
        .eq('id', inventoryItem.id);
    } else {
      await supabase
        .from('inventory')
        .insert({
          user_id: userId,
          item_type: harvestedType,
          quantity: 1
        });
    }

    loadGameData();
  }

  async function buySeeds(cropType: string, amount: number) {
    if (!profile || !userId) return;

    const crop = CROPS[cropType];
    const totalCost = crop.seedCost * amount;

    if (profile.coins < totalCost) {
      alert('Nuk ke monedha të mjaftueshme!');
      return;
    }

    const seedType = `${cropType}_seed`;
    const inventoryItem = inventory.find(item => item.item_type === seedType);

    await supabase
      .from('profiles')
      .update({ coins: profile.coins - totalCost })
      .eq('id', userId);

    if (inventoryItem) {
      await supabase
        .from('inventory')
        .update({ quantity: inventoryItem.quantity + amount })
        .eq('id', inventoryItem.id);
    } else {
      await supabase
        .from('inventory')
        .insert({
          user_id: userId,
          item_type: seedType,
          quantity: amount
        });
    }

    loadGameData();
  }

  return {
    profile,
    plots,
    inventory,
    loading,
    plantCrop,
    harvestCrop,
    buySeeds,
    refreshData: loadGameData
  };
}
